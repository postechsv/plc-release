import glob
import os

oldname = []
newname = []

for name in glob.glob('/home/jlee/plc-release/apps/icalpexp/*-*-p*.maude'):
    oldname += [name]
    newname += [name.replace('-p', '-a')]

for i in range(len(oldname)):
    os.system('cp ' + oldname[i] + ' ' + newname[i])
