import glob
import os

oldname = []
newname = []

for name in glob.glob('/home/jlee/plc-release/apps/icalpexp/log-con-*'):
    oldname += [name]
    newname += [name.replace('con', 'gcd')]

for i in range(len(oldname)):
    os.system('mv ' + oldname[i] + ' ' + newname[i])
